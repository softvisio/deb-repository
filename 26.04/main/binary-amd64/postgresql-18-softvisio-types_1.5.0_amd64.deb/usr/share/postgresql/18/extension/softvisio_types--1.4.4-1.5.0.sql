\echo 'You need to use the following commands:'
\echo 'CREATE EXTENSION IF NOT EXISTS softvisio_types;'
\echo 'ALTER EXTENSION softvisio_types UPDATE;'
\echo \quit

CREATE OR REPLACE FUNCTION lo_size ( lo_oid oid ) RETURNS int53 VOLATILE AS $$
DECLARE
    v_fd int4;
    v_size int53;
BEGIN
    -- open the large object in read-only mode.
    v_fd := lo_open( lo_size.lo_oid, 262144 ); -- INV_READ

    IF v_fd < 0 THEN
        RAISE EXCEPTION 'Failed to open large object %', lo_size.lo_oid;
    END IF;

    BEGIN
        -- seek to the end and obtain the 64-bit size.
        v_size := lo_lseek64( v_fd, 0, 2 ); -- SEEK_END

        IF v_size < 0 THEN
            RAISE EXCEPTION 'Failed to determine size of large object %', lo_size.lo_oid;
        END IF;

    EXCEPTION WHEN OTHERS THEN

        -- try to close the object without masking the original error.
        BEGIN
            PERFORM lo_close( v_fd );
        EXCEPTION WHEN OTHERS THEN
            NULL;
        END;

        RAISE;
    END;

    -- close the object and check the result.
    IF lo_close( v_fd ) <> 0 THEN
        RAISE EXCEPTION 'Failed to close large object %', lo_size.lo_oid;
    END IF;

    RETURN v_size;
END;
$$ LANGUAGE plpgsql;
