#!/usr/bin/env bash

if [[ -z ${FNM_DIR:-} ]]; then
    export FNM_DIR=$(realpath ~)/.local/share/fnm
    export FNM_MULTISHELL_PATH=$FNM_DIR/current

    export FNM_VERSION_FILE_STRATEGY=local
    export FNM_LOGLEVEL=info
    export FNM_NODE_DIST_MIRROR=https://nodejs.org/dist
    export FNM_COREPACK_ENABLED=false
    export FNM_RESOLVE_ENGINES=false
    export FNM_ARCH=x64
fi

[[ :$PATH: == *":$FNM_MULTISHELL_PATH/bin:"* ]] || PATH="$FNM_MULTISHELL_PATH/bin:$PATH"
